<template>
  <div id="app">
<!--    <h1>Cloudy</h1>-->
<!--    <router-link to="/button">button</router-link>-->
<!--    <router-link to="calender">calender</router-link>-->
<!--    <router-link to="image">image</router-link>-->
<!--    <router-link tp="pagination">pagination</router-link>-->
<!--    <router-link to="select">select</router-link>-->
<!--    <router-link to="/login">请登录</router-link>-->
<!--    <router-link to="/main">shouYe</router-link>-->
    <router-view></router-view>
  </div>
</template>

<script>
  export default {
    name:'App'
  }
</script>
